@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Run START.bat first to install dependencies.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -m playwright install chromium
pause
