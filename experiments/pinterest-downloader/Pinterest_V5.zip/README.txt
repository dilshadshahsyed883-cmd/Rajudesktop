PINTEREST VIDEO DOWNLOADER V5 — EXPERIMENTAL

Windows, Python 3.10+, installed Chrome recommended. Extract the whole ZIP.
Close any running V3/V4 test app and its test Chrome window before starting V5.
Double-click START.bat. It installs the Python dependencies when needed.
If Chrome is unavailable, use INSTALL_CHROMIUM.bat for the bundled browser.

Paste one individual Pinterest video Pin URL per line, select output folder,
and click Start downloads. V5 opens visible Chrome using the same separate
persistent browser profile as V3 (not your ordinary Chrome profile).
Login is optional unless Pinterest requests it. If prompted, sign in in
Chrome normally and reopen the original Pin within 3 minutes. The app does
not ask for, export, or log your credentials or cookies. Session persistence
is subject to Pinterest/Chrome session expiry. Play the requested video if
it does not autoplay.

V5 automatically selects streams only if it can associate them with the
requested Pin. If attribution fails after 18 seconds and streams exist,
choose the correct video family from the dropdown and click Save selected
stream. Compare the stream with the requested video; the dropdown is not
proof of attribution. If unsure, skip the Pin. Each group shows the largest
observed explicit resolution, or a master playlist if no variant is known.
Multiple links run sequentially; the Chrome profile is reused for the batch.
Video-only MP4, stream copy, no audio, no overwrite. FFmpeg checks that a
video frame can decode before publishing. Cancel and Retry failed supported.

V4 background mode is disabled because it failed on the reported test.
V3 was verified on the user's actual Pin; V5 has local regression tests only.
Automatic identification and login flow on live Pinterest/Windows have not
been verified. Some Pins may not expose accessible video streams.
Download only content you have permission to use. No Rajudesktop changes.
