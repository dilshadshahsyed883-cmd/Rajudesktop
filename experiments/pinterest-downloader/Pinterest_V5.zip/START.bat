@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  py -3 -m venv .venv
  if errorlevel 1 python -m venv .venv
  if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" -c "import playwright, imageio_ffmpeg" >nul 2>&1
if errorlevel 1 (
  echo Installing Playwright and FFmpeg dependencies...
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 goto fail
)
".venv\Scripts\python.exe" app.py
if errorlevel 1 goto fail
exit /b 0
:fail
echo Setup failed. Install Python 3.10+ and check internet connectivity.
pause
exit /b 1
