"""Experimental automatic Pinterest video queue. No Pinterest API calls outside browser."""
import os, re, json, time, queue, threading, subprocess, tempfile, shutil
from pathlib import Path
from urllib.parse import urlsplit, urljoin
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

PIN_HOST = re.compile(r'(?:[a-z0-9-]+\.)?pinterest\.(?:com|[a-z]{2}|co\.[a-z]{2}|com\.[a-z]{2})$', re.I)
PIN_PATH = re.compile(r'/pin/(?:[^/]*--)?(\d+)/?$', re.I)

def pin_id(url):
    p=urlsplit(url); m=PIN_PATH.fullmatch(p.path)
    return m.group(1) if p.scheme=='https' and p.hostname and PIN_HOST.fullmatch(p.hostname) and m else None

def validate(url):
    p=urlsplit(url)
    if p.scheme=='https' and not p.username and not p.password and (pin_id(url) or (p.hostname in ('pin.it','www.pin.it') and p.path.strip('/'))): return url
    raise ValueError('Use an HTTPS individual Pinterest Pin or pin.it link.')

def media_kind(url, content_type=""):
    p=urlsplit(url)
    if p.scheme!='https' or p.username or p.password or not p.hostname or not (p.hostname=='pinimg.com' or p.hostname.endswith('.pinimg.com')): return None
    path=p.path.lower()
    if re.search(r'(?:_|[-/])audio(?:[_\-./]|$)',path): return None
    mime=content_type.lower().split(';')[0].strip()
    if path.endswith('.m3u8') or mime in ('application/vnd.apple.mpegurl','application/x-mpegurl','audio/mpegurl'): return 'HLS'
    if path.endswith('.mp4'): return 'MP4'
    return None

def family(url):
    p=urlsplit(url); stem=p.path.rsplit('/',1)[-1].rsplit('.',1)[0]
    base=re.sub(r'_(?:\d+[wp]|audio)(?:_.*)?$','',stem,flags=re.I)
    return base.lower() if re.fullmatch(r'[0-9a-fA-F]{24,64}',base) else p.netloc+p.path.rsplit('/',1)[0]+'/'+base

def master(url): return media_kind(url)=='HLS' and not re.search(r'_\d+[wp](?:_|\.)',urlsplit(url).path,re.I)

def dimension(url):
    m=re.search(r'(?:_|/)(\d+)[wp](?:_|/|\.)',urlsplit(url).path,re.I)
    return int(m.group(1)) if m else 0

def metadata_candidates(obj, target):
    """Only take media within a record explicitly identified by the requested Pin ID."""
    found={}; stack=[obj]
    def walk_media(value):
        todo=[value]
        while todo:
            node=todo.pop()
            if isinstance(node,dict):
                u=node.get('url') or node.get('src')
                if isinstance(u,str) and media_kind(u):
                    sizes=[]
                    for key in ('width','height'):
                        try: sizes.append(int(node.get(key,0) or 0))
                        except (TypeError,ValueError): pass
                    found[u]=max([found.get(u,0),dimension(u),*sizes])
                for k,v in node.items():
                    if k not in ('related_pins','relatedPins','recommendations','other_pins','otherPins'): todo.append(v)
            elif isinstance(node,list): todo.extend(node)
            elif isinstance(node,str) and media_kind(node): found[node]=max(found.get(node,0),dimension(node))
    while stack:
        node=stack.pop()
        if isinstance(node,dict):
            if any(str(node.get(k,''))==target for k in ('id','pin_id','pinId')):
                for k in ('videos','video','video_list','videoList','videoUrls','story_pin_data','storyPinData'):
                    if k in node: walk_media(node[k])
            # Some normalized stores key pin records by their ID.
            if target in node and isinstance(node[target],dict):
                rec=node[target]
                for k in ('videos','video','video_list','videoList','story_pin_data','storyPinData'):
                    if k in rec: walk_media(rec[k])
            stack.extend(v for v in node.values() if isinstance(v,(dict,list)))
        elif isinstance(node,list): stack.extend(v for v in node if isinstance(v,(dict,list)))
    return found

def select_stream(verified, network):
    if not verified: return None
    families={family(u) for u in verified}
    if len(families)>1:
        # Multiple metadata families can be distinct encodes or story pages. Do not guess.
        # A single matching captured family disambiguates the actual player.
        active={family(u) for u in network if family(u) in families}
        if len(active)!=1: return None
        families=active
    pool={u:q for u,q in verified.items() if family(u) in families}
    for u in network:
        if family(u) in families and media_kind(u): pool[u]=max(pool.get(u,0),dimension(u))
    # Master manifest lets FFmpeg choose highest video resolution. Prefer observed URL on ties.
    return max(pool,key=lambda u:(master(u),pool[u],u in network,media_kind(u)=='MP4'))

def ffmpeg_command(exe,url,out,ua,referer):
    return [exe,'-hide_banner','-nostdin','-loglevel','warning','-rw_timeout','20000000','-user_agent',ua,'-headers',f'Referer: {referer}\r\n','-i',url,'-an','-sn','-dn','-c:v','copy','-movflags','+faststart','-y',str(out)]

def publish(source, folder, ident):
    if not source.is_file() or source.stat().st_size==0: raise RuntimeError('Empty output.')
    for i in range(1,100000):
        path=folder/f'Pinterest_{ident}{"" if i==1 else "_"+str(i)}.mp4'
        try:
            with path.open('xb') as dst:
                try:
                    with source.open('rb') as src: shutil.copyfileobj(src,dst)
                except BaseException: dst.close(); path.unlink(missing_ok=True); raise
            return path
        except FileExistsError: continue
    raise RuntimeError('Too many existing files.')

# DOM source is accepted only in a Pin closeup container or an explicit link to the requested Pin.
DOM_JS = r'''(id) => {
 const visible = v=>{const r=v.getBoundingClientRect();return r.width>100&&r.height>100&&r.bottom>0&&r.top<innerHeight&&r.right>0&&r.left<innerWidth};
 const exact = [...document.querySelectorAll('[data-pin-id],a[href*="/pin/"]')].filter(e=> e.getAttribute('data-pin-id')===id || (e.getAttribute('href')||'').split('?')[0].replace(/\/$/,'').endsWith('/pin/'+id));
 const close = [...document.querySelectorAll('[data-test-id="pin-closeup"],[data-test-id="pin-closeup-container"],[data-test-id="closeup-image"],[data-test-id="pin-closeup-video"],[data-test-id="closeup-video"]')];
 const scoped = [...new Set([...exact,...close].flatMap(e=>[...(e.matches('video')?[e]:[]),...e.querySelectorAll('video')]))].filter(visible);
 const all=[...document.querySelectorAll('video')].filter(visible);
 const v=scoped.length===1?scoped[0]:all.length===1?all[0]:null;
 if(!v)return [];
 v.muted=true; if(v.paused)v.play().catch(()=>{});
 // Only explicit target/closeup scope can establish attribution; blob URLs are not media URLs.
 return scoped.length===1?[v.currentSrc,v.src,...[...v.querySelectorAll('source')].map(s=>s.src)].filter(Boolean):[];
}'''

def manual_choices(network):
    """One best candidate per captured video family; never select a family by guess."""
    groups={}
    for u in network:
        if media_kind(u): groups.setdefault(family(u),[]).append(u)
    return [max(us,key=lambda u:(dimension(u),master(u),media_kind(u)=='MP4',u)) for us in groups.values()]

class Worker(threading.Thread):
    def __init__(self, items, folder, events, stop, commands):
        super().__init__(daemon=True); self.items=items; self.folder=folder; self.events=events; self.stop=stop; self.commands=commands
    def emit(self,*event): self.events.put(event)
    def log(self,s): self.emit('log',s)
    def check(self):
        if self.stop.is_set(): raise RuntimeError('Cancelled')
    def browser(self,pw):
        # Reuse V3's tested profile, including any normal user login.
        profile=Path(os.environ.get('LOCALAPPDATA',str(Path.home())))/'PinterestCaptureV3'/'BrowserProfile'
        opts=dict(headless=False,viewport=None,accept_downloads=False)
        try: return pw.chromium.launch_persistent_context(str(profile),channel='chrome',**opts)
        except Exception: return pw.chromium.launch_persistent_context(str(profile),**opts)
    def run(self):
        ctx=None; saved=failed=0
        try:
            from playwright.sync_api import sync_playwright
            import imageio_ffmpeg
            exe=shutil.which('ffmpeg') or imageio_ffmpeg.get_ffmpeg_exe()
            self.folder.mkdir(parents=True,exist_ok=True)
            with sync_playwright() as pw:
                try:
                    ctx=self.browser(pw)
                    self.log('Visible Chrome opened using persistent V3 profile. Login only if Pinterest asks.')
                    for idx,url in enumerate(self.items):
                        if self.stop.is_set(): break
                        self.emit('status',idx,'Resolving / downloading'); self.log(f'[{idx+1}/{len(self.items)}] {url}')
                        try:
                            self.capture(ctx,url,exe)
                            saved+=1; self.emit('status',idx,'Completed')
                        except Exception as e:
                            if self.stop.is_set(): self.emit('status',idx,'Cancelled'); break
                            failed+=1; self.emit('status',idx,'Failed'); self.log('FAILED: '+redact(str(e)))
                finally:
                    if ctx: ctx.close()
        except Exception as e: self.log('Setup error: '+redact(str(e)))
        finally: self.emit('done',saved,failed)
    def capture(self,ctx,url,exe):
        # Reuse the initial tab (same as V3); attach listeners before navigating.
        page=ctx.pages[0] if ctx.pages else ctx.new_page()
        network=set(); pending=[]; verified={}; seen=set(); target=pin_id(url)
        def response(r):
            try:
                if r.status not in (200,206): return
                if media_kind(r.url): network.add(r.url)
                elif PIN_HOST.fullmatch(urlsplit(r.url).hostname or '') and 'json' in r.headers.get('content-type','').lower() and r.request.resource_type in ('xhr','fetch'):
                    if len(pending)<100: pending.append(r)
            except Exception: pass
        page.on('response',response)
        try:
            try: page.goto(url,wait_until='domcontentloaded',timeout=30000)
            except Exception as e: self.log('Navigation notice: '+type(e).__name__+'; browser remains open.')
            started=time.monotonic(); last_change=started; previous=None; selected=None; arrived=None; prompted=False; offered=None
            self.log('If login is requested, sign in normally, then reopen the original Pin. Play it if autoplay fails.')
            while time.monotonic()-started<180:
                self.check()
                if page.is_closed(): raise RuntimeError('Chrome tab was closed.')
                actual=pin_id(page.url)
                if not actual or (target and actual!=target):
                    if arrived is not None:
                        network.clear(); pending.clear(); verified.clear(); seen.clear(); arrived=None; offered=None; previous=None
                    if not prompted:
                        self.log('Waiting for requested Pin in Chrome (up to 3 minutes).'); prompted=True
                    page.wait_for_timeout(500); continue
                target=actual
                if arrived is None: arrived=time.monotonic(); self.log('Requested Pin opened: '+target)
                for r in pending[:]:
                    pending.remove(r)
                    try:
                        if int(r.headers.get('content-length','0') or '0')>8_000_000: continue
                        verified.update(metadata_candidates(r.json(),target))
                    except Exception: pass
                try:
                    scripts=page.evaluate('''() => [...document.querySelectorAll('script[type="application/json"],script[type="application/ld+json"],script[id*="PWS_DATA"],script[id*="__NEXT_DATA__"]')].map(s=>s.textContent).filter(s=>s&&s.length<10000000)''')
                    for script in scripts:
                        if script in seen: continue
                        seen.add(script)
                        try: verified.update(metadata_candidates(json.loads(script),target))
                        except (ValueError,TypeError): pass
                    for u in page.evaluate(DOM_JS,target):
                        if media_kind(u): verified[u]=max(verified.get(u,0),dimension(u))
                except Exception: pass
                selected=select_stream(verified,network)
                if selected!=previous: last_change=time.monotonic(); previous=selected
                if selected and time.monotonic()-last_change>=4: break
                if time.monotonic()-arrived>=18 and network:
                    choices=manual_choices(network)
                    if choices and offered!=choices:
                        offered=choices; self.emit('choices',choices); self.log(f'{len(network)} media URLs; {len(verified)} verified. If automatic detection cannot identify the Pin, select its stream below.')
                    try: action,chosen=self.commands.get_nowait()
                    except queue.Empty: pass
                    else:
                        if action=='skip': raise RuntimeError('Skipped by user.')
                        if action=='save' and chosen in network and media_kind(chosen):
                            selected=chosen; self.log('User confirmed stream selection.'); break
                page.wait_for_timeout(500)
            if pin_id(page.url)!=target: raise RuntimeError('Requested Pin did not open or was navigated away from.')
            self.log(f'Captured {len(network)} media URLs; {len(verified)} linked to Pin {target}.')
            if not selected: raise RuntimeError('No verified or user-confirmed video stream. Retry and play the requested video in Chrome.')
            self.emit('choices',[])
            self.log('Selected: '+urlsplit(selected).path+' (video only)')
            ua=page.evaluate('navigator.userAgent'); p=urlsplit(page.url)
            self.save(exe,selected,target,ua,f'{p.scheme}://{p.netloc}/')
        finally:
            self.emit('choices',[])
            page.remove_listener('response',response)
            while True:
                try: self.commands.get_nowait()
                except queue.Empty: break
    def process(self,cmd,log,timeout):
        proc=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        start=time.monotonic()
        try:
            while proc.poll() is None:
                self.check()
                if time.monotonic()-start>timeout: raise RuntimeError('FFmpeg timeout')
                self.stop.wait(.2)
            if proc.returncode: raise RuntimeError(f'FFmpeg exited {proc.returncode}')
        finally:
            if proc.poll() is None: proc.kill(); proc.wait()
    def save(self,exe,url,ident,ua,ref):
        with tempfile.TemporaryDirectory(prefix='pin-',dir=self.folder) as d:
            temp=Path(d)/'video.mp4'; logs=Path(d)/'ffmpeg.log'
            try:
                with logs.open('wb') as f:
                    self.process(ffmpeg_command(exe,url,temp,ua,ref),f,600)
                    self.process([exe,'-hide_banner','-nostdin','-v','error','-xerror','-i',str(temp),'-map','0:v:0','-frames:v','1','-f','null','-'],f,30)
            except Exception as e: raise RuntimeError(str(e)+': '+redact(logs.read_text(encoding='utf-8',errors='replace')[-1500:])) from e
            self.check(); path=publish(temp,self.folder,ident); self.log('SAVED: '+str(path))

def redact(s): return re.sub(r'https?://[^\s\]\)\'\"]+','[URL]',s)

class App:
    def __init__(self,root):
        self.root=root; root.title('Pinterest Video Downloader — V5 — Persistent Chrome'); root.geometry('1000x740'); root.minsize(660,500)
        self.events=queue.Queue(); self.stop=threading.Event(); self.worker=None; self.folder=tk.StringVar(value=str(Path.home()/'Downloads'/'Pinterest Videos')); self.commands=queue.Queue(); self.status=tk.StringVar(value='Ready'); self.rows=[]; self.links=[]; self.closing=False
        f=ttk.Frame(root,padding=15); f.pack(fill='both',expand=True)
        ttk.Label(f,text='Pinterest Video Downloader V5',font=('Segoe UI',19,'bold')).pack(anchor='w'); ttk.Label(f,text='Automatic browser capture • Multiple links • Video-only MP4').pack(anchor='w',pady=(0,12))
        ttk.Label(f,text='Paste one Pinterest video link per line').pack(anchor='w'); self.input=tk.Text(f,height=5); self.input.pack(fill='x',pady=(3,8))
        ttk.Label(f,text='Output folder').pack(anchor='w'); row=ttk.Frame(f); row.pack(fill='x'); ttk.Entry(row,textvariable=self.folder).pack(side='left',fill='x',expand=True); ttk.Button(row,text='Browse',command=self.browse).pack(side='left',padx=4); ttk.Button(row,text='Open folder',command=self.open_folder).pack(side='left')
        ttk.Label(f,text='Visible Chrome • Login only if requested • Saved session reused').pack(anchor='w',pady=7)
        row=ttk.Frame(f); row.pack(fill='x'); self.startbtn=ttk.Button(row,text='Start downloads',command=self.start); self.startbtn.pack(side='left'); self.retrybtn=ttk.Button(row,text='Retry failed',command=lambda:self.start(True),state='disabled'); self.retrybtn.pack(side='left',padx=5); self.cancelbtn=ttk.Button(row,text='Cancel',command=self.cancel,state='disabled'); self.cancelbtn.pack(side='left'); ttk.Button(row,text='Save log',command=self.save_log).pack(side='right')
        self.tree=ttk.Treeview(f,columns=('url','status'),show='headings',height=7); self.tree.heading('url',text='Pinterest video URL'); self.tree.heading('status',text='Status'); self.tree.column('url',width=560); self.tree.column('status',width=180); self.tree.pack(fill='x',pady=9)
        self.choice_urls=[]; self.choice=tk.StringVar(); cr=ttk.Frame(f); cr.pack(fill='x'); self.combo=ttk.Combobox(cr,textvariable=self.choice,state='disabled',width=68); self.combo.pack(side='left',fill='x',expand=True); self.confirm=ttk.Button(cr,text='Save selected stream',state='disabled',command=self.confirm_stream); self.confirm.pack(side='left',padx=4); self.skip=ttk.Button(cr,text='Skip Pin',state='disabled',command=lambda:self.commands.put(('skip',None))); self.skip.pack(side='left');
        self.bar=ttk.Progressbar(f,mode='determinate'); self.bar.pack(fill='x'); ttk.Label(f,textvariable=self.status).pack(anchor='w',pady=4); ttk.Label(f,text='Diagnostic log').pack(anchor='w'); self.logs=tk.Text(f,height=9,wrap='word',state='disabled',font=('Consolas',10)); self.logs.pack(fill='both',expand=True)
        root.protocol('WM_DELETE_WINDOW',self.close); root.after(100,self.poll)
    def browse(self):
        d=filedialog.askdirectory();
        if d: self.folder.set(d)
    def open_folder(self):
        try: p=Path(self.folder.get()); p.mkdir(parents=True,exist_ok=True); os.startfile(p)
        except Exception as e: messagebox.showerror('Folder',str(e))
    def save_log(self):
        p=filedialog.asksaveasfilename(defaultextension='.txt');
        if p: Path(p).write_text(self.logs.get('1.0','end-1c'),encoding='utf-8')
    def start(self,retry=False):
        if self.worker: return
        try:
            raw=[self.links[i] for i,r in enumerate(self.rows) if self.tree.item(r,'values')[1] in ('Failed','Cancelled','Waiting')] if retry else self.input.get('1.0','end').splitlines()
            links=list(dict.fromkeys(validate(s.strip()) for s in raw if s.strip()))
            if not links or not self.folder.get().strip(): raise ValueError('Enter links and output folder.')
        except Exception as e: messagebox.showerror('Input',str(e)); return
        self.links=links; self.tree.delete(*self.tree.get_children()); self.rows=[self.tree.insert('','end',values=(u,'Waiting')) for u in links]; self.bar.config(maximum=len(links),value=0)
        self.stop=threading.Event(); self.commands=queue.Queue(); self.worker=Worker(links,Path(self.folder.get()),self.events,self.stop,self.commands); self.startbtn.config(state='disabled'); self.retrybtn.config(state='disabled'); self.cancelbtn.config(state='normal'); self.status.set('Running…'); self.worker.start()
    def confirm_stream(self):
        i=self.combo.current()
        if 0<=i<len(self.choice_urls): self.commands.put(("save",self.choice_urls[i])); self.confirm.config(state="disabled")
    def cancel(self): self.stop.set(); self.status.set('Cancelling…')
    def close(self):
        self.closing=True; self.cancel()
        if not self.worker: self.root.destroy()
    def poll(self):
        while True:
            try: typ,*a=self.events.get_nowait()
            except queue.Empty: break
            if typ=='log': self.logs.config(state='normal'); self.logs.insert('end',a[0]+'\n'); self.logs.see('end'); self.logs.config(state='disabled')
            elif typ=='choices':
                self.choice_urls=a[0]; self.choice.set(''); self.combo.config(values=[urlsplit(u).path for u in self.choice_urls],state='readonly' if self.choice_urls else 'disabled'); self.confirm.config(state='normal' if self.choice_urls else 'disabled'); self.skip.config(state='normal' if self.choice_urls else 'disabled')
            elif typ=='status': self.tree.item(self.rows[a[0]],values=(self.links[a[0]],a[1])); self.bar.config(value=sum(self.tree.item(r,'values')[1] in ('Completed','Failed','Cancelled') for r in self.rows))
            elif typ=='done':
                self.worker=None; self.startbtn.config(state='normal'); self.cancelbtn.config(state='disabled'); self.retrybtn.config(state='normal' if any(self.tree.item(r,'values')[1]!='Completed' for r in self.rows) else 'disabled'); self.status.set(f'Finished — {a[0]} saved, {a[1]} failed, {len(self.rows)-sum(a)} not completed')
                if self.closing: self.root.destroy(); return
        self.root.after(100,self.poll)

if __name__=='__main__':
    root=tk.Tk(); App(root); root.mainloop()
