import unittest, tempfile, threading, queue, shutil, subprocess
from pathlib import Path
from app import *
BASE='https://v1.pinimg.com/videos/iht/hls/62/fd/e5/62fde5b683261538d607e509fbe9dbb4'
OTHER='https://v1.pinimg.com/videos/iht/hls/cf/cc/9a/cfcc9aaae348feca3dd82fa84a82219f.m3u8'
PIN='986992074614792105'
class Tests(unittest.TestCase):
    def test_pin(self):
        self.assertEqual(pin_id(validate('https://www.pinterest.com/pin/'+PIN+'/')),PIN)
        self.assertEqual(validate('https://pin.it/abc'),'https://pin.it/abc')
        for bad in ['http://pin.it/a','https://pinterest.com.evil.net/pin/123/','https://pinterest.com/board/','https://user@pinterest.com/pin/123/']:
            with self.assertRaises(ValueError): validate(bad)
    def test_filter(self):
        self.assertIsNone(media_kind(BASE+'_audio.m3u8')); self.assertIsNone(media_kind('https://evil.net/a.mp4')); self.assertIsNone(media_kind(BASE+'.ts'))
    def test_exact_pin(self):
        fixture={'data':[{'id':PIN,'videos':{'video_list':{'V_HLS':{'url':BASE+'.m3u8'}}}},{'id':'99','videos':{'video_list':{'V_HLS':{'url':OTHER}}}}]}
        self.assertEqual(set(metadata_candidates(fixture,PIN)),{BASE+'.m3u8'})
    def test_real_log_families(self):
        observed={BASE+'.m3u8',BASE+'_240w.m3u8',BASE+'_audio.m3u8',BASE+'_720w.m3u8',OTHER}
        self.assertEqual(select_stream({BASE+'_240w.m3u8':240},observed),BASE+'.m3u8')
        self.assertEqual(select_stream({BASE+'_240w.m3u8':240},observed-{BASE+'.m3u8'}),BASE+'_720w.m3u8')
    def test_no_attribution(self): self.assertIsNone(select_stream({}, {BASE+'.m3u8',OTHER}))
    def test_ambiguous(self): self.assertIsNone(select_stream({BASE+'.m3u8':0,OTHER:0},{BASE+'.m3u8',OTHER}))
    def test_manual_fallback_real_log(self):
        observed={BASE+'.m3u8',BASE+'_240w.m3u8',BASE+'_audio.m3u8',BASE+'_720w.m3u8',OTHER}
        self.assertEqual(set(manual_choices(observed)),{BASE+'_720w.m3u8',OTHER})
    def test_manual_fallback_empty_and_audio(self):
        self.assertEqual(manual_choices({BASE+'_audio.m3u8'}),[])
        self.assertEqual(manual_choices(set()),[])
    def test_manual_fallback_never_auto_confirms(self):
        self.assertIsNone(select_stream({}, {BASE+'_720w.m3u8'}))
    def test_persistent_visible_profile(self):
        from unittest.mock import Mock,patch
        pw=Mock(); w=Worker([],Path('.'),queue.Queue(),threading.Event(),queue.Queue())
        with patch.dict(os.environ,{'LOCALAPPDATA':'/tmp/localappdata'}): w.browser(pw)
        args,kwargs=pw.chromium.launch_persistent_context.call_args
        self.assertTrue(args[0].endswith(str(Path('PinterestCaptureV3')/'BrowserProfile')))
        self.assertFalse(kwargs['headless']); self.assertEqual(kwargs['channel'],'chrome')
    def test_generic_family(self): self.assertNotEqual(family('https://v1.pinimg.com/a/video.mp4'),family('https://v1.pinimg.com/b/video.mp4'))
    def test_output(self):
        with tempfile.TemporaryDirectory() as d:
            folder=Path(d); f=folder/'source'; f.write_bytes(b'abc'); a=publish(f,folder,PIN); b=publish(f,folder,PIN); self.assertNotEqual(a,b); self.assertEqual(a.read_bytes(),b'abc')
    def test_ffmpeg_options(self):
        cmd=ffmpeg_command('ffmpeg',BASE+'.m3u8','out.mp4','UA','https://pinterest.com/'); self.assertIn('-an',cmd); self.assertIn('copy',cmd); self.assertNotIn('-map',cmd)
    @unittest.skipUnless(shutil.which('ffmpeg'),'system ffmpeg unavailable')
    def test_actual_ffmpeg_video_only(self):
        exe=shutil.which('ffmpeg')
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'source.mp4'; out=Path(d)/'out.mp4'
            subprocess.run([exe,'-v','error','-f','lavfi','-i','color=c=black:s=128x96:r=10:d=1','-f','lavfi','-i','sine=frequency=1000:duration=1','-c:v','mpeg4','-c:a','aac','-shortest',str(f)],check=True)
            # local input; omit HTTP-only input options
            subprocess.run([exe,'-v','error','-i',str(f),'-an','-sn','-dn','-c:v','copy','-movflags','+faststart',str(out)],check=True)
            probe=subprocess.run([exe,'-hide_banner','-i',str(out)],capture_output=True,text=True).stderr
            self.assertIn('Video:',probe); self.assertNotIn('Audio:',probe)
if __name__=='__main__': unittest.main()
