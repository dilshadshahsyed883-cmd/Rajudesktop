IMAGEYE QUEUE AUTOMATION — Windows prototype v1.2

1. Extract ZIP. Install Python 3.11/3.12 from python.org if needed.
2. In Chrome, pin Imageye to the toolbar, maximize Chrome on the primary monitor, and use the same light theme as the supplied screenshots. Sign in normally if required.
3. Chrome Settings > Downloads: select a known folder; turn off 'Ask where to save each file before downloading' if you want unattended downloads. If Chrome asks permission for multiple downloads, handle it manually before a queue run. Do not run other downloads concurrently.
4. Double-click START.bat. The first launch installs dependencies into a local virtual environment. Later starts reuse it.
5. Paste authorized URLs, one per line, or load a .txt file. Select the exact folder where Imageye saves. Test ONE URL first.
6. Optional but recommended for repeated tabs: open Imageye manually, click 'Calibrate panel X' in the app, then move your cursor to Imageye's panel close X during the 5-second countdown. The app records that position for this session. Close Imageye manually before pressing Start. Do not move or resize Chrome during the queue.
7. Confirm permission and click Start. It opens a new tab, detects the pinned icon, waits for Select all, clicks Download, waits at least 60 seconds (adjustable 60–180 seconds) while monitoring folder changes, then closes the side panel if calibrated, closes the tab, and repeats.
8. If a matching button is not found, Chrome loses focus, or the download folder does not settle, the run stops, leaving the tab open. Remove completed URLs before retrying. Pause/Stop controls are accessible from the minimized app, but Chrome must be foreground again when resuming. Emergency stop: move mouse to the top-left corner.

LIMITATIONS
- This is a prototype, not tested against a live Windows Chrome/Imageye instance here. Templates are cropped from your screenshots; Chrome DPI, theme, toolbar placement, UI updates and the active profile can affect detection. The app searches only the primary screen toolbar/header. It does not use an API or modify Imageye.
- Completion is inferred from new/updated nonempty files, absence of changed temporary download files, and a configurable period of folder inactivity. The minimum wait starts after clicking Download, defaults to 60 seconds, and can be set to 60–180 seconds. If downloading is still active after that, the app continues checking until completion or the download timeout; on timeout the tab stays open. This does NOT prove all selected images downloaded. Increase quiet time for slow batches. Check the Chrome download list and compare counts after the first run. A ZIP counts as one file. Existing unrelated downloads can make detection unreliable.
- A persistent side panel with old results causes a safe stop. Calibrate its close X or close the panel manually between tests. If Imageye displays a confirmation dialog, resolve it manually. Do not use the mouse/keyboard while automated clicks are happening.
- Use only content you are authorized to download and use. Does not bypass licenses, watermarks, paywalls or authentication. Preview availability does not grant reuse rights.
