import ctypes
import os
import queue
import subprocess
import threading
import time
from pathlib import Path
from urllib.parse import urlparse
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

# Use physical screen pixels on Windows, including high-DPI screens.
if os.name == 'nt':
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
import cv2
import numpy as np
import pyautogui as pg

BASE = Path(__file__).resolve().parent
pg.FAILSAFE = True
pg.PAUSE = .2
TEMP_EXT = ('.crdownload', '.part', '.tmp', '.download')

def chrome_path():
    for base in (os.environ.get('PROGRAMFILES'), os.environ.get('PROGRAMFILES(X86)'), os.environ.get('LOCALAPPDATA')):
        if base:
            p = Path(base) / 'Google/Chrome/Application/chrome.exe'
            if p.is_file():
                return str(p)
    raise RuntimeError('Google Chrome executable not found.')

def chrome_foreground():
    user32 = ctypes.windll.user32
    hwnd = user32.GetForegroundWindow()
    buf = ctypes.create_unicode_buffer(256)
    user32.GetClassNameW(hwnd, buf, 256)
    title = ctypes.create_unicode_buffer(1024)
    user32.GetWindowTextW(hwnd, title, 1024)
    return buf.value.startswith('Chrome_WidgetWin') and 'Google Chrome' in title.value

def snapshot(folder):
    out = {}
    for p in folder.rglob('*'):
        try:
            if p.is_file():
                s = p.stat()
                out[str(p)] = (s.st_size, s.st_mtime_ns)
        except OSError:
            continue
    return out

def changes(before, now):
    return {p: v for p,v in now.items() if before.get(p) != v}

class Stopped(Exception):
    pass

class Runner:
    def __init__(self, config, events):
        self.c = config
        self.events = events
        self.stop = threading.Event()
        self.pause = threading.Event()
        self.templates = {}
        for name in ('extension','select_all','download'):
            p = BASE/'templates'/f'{name}.png'
            t = cv2.imread(str(p), cv2.IMREAD_GRAYSCALE)
            if t is None:
                raise RuntimeError(f'Missing template: {p.name}')
            self.templates[name] = t
    def log(self, msg):
        self.events.put(('log', msg))
    def check(self):
        if self.stop.is_set(): raise Stopped()
        while self.pause.is_set():
            if self.stop.wait(.2): raise Stopped()
        if self.stop.is_set(): raise Stopped()
    def wait(self, seconds):
        end = time.monotonic()+seconds
        while time.monotonic()<end:
            self.check()
            time.sleep(.2)
    def require_chrome(self):
        self.check()
        if not chrome_foreground():
            raise RuntimeError('Chrome is not in the foreground. No further clicks made.')
    def match(self, name):
        self.require_chrome()
        im = np.array(pg.screenshot())
        h,w = im.shape[:2]
        # Search toolbar / side panel header only; never click web content.
        x0 = int(w*.55) if name=='extension' else int(w*.65)
        y0 = 0 if name=='extension' else int(h*.07)
        y1 = int(h*.085) if name=='extension' else int(h*.23)
        crop = cv2.cvtColor(im[y0:y1,x0:w],cv2.COLOR_RGB2GRAY)
        best = (-1,None)
        t = self.templates[name]
        for scale in (.7,.8,.9,1,1.1,1.2,1.3,1.5,1.7,2):
            tw,th = max(1,round(t.shape[1]*scale)), max(1,round(t.shape[0]*scale))
            if tw>crop.shape[1] or th>crop.shape[0]: continue
            resized = cv2.resize(t,(tw,th),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_CUBIC)
            score = cv2.matchTemplate(crop,resized,cv2.TM_CCOEFF_NORMED)
            _,val,_,pos = cv2.minMaxLoc(score)
            if val>best[0]: best=(val,(x0+pos[0]+tw//2,y0+pos[1]+th//2))
        return best[1] if best[0]>=self.c['confidence'] else None
    def find(self,name,timeout):
        end=time.monotonic()+timeout
        while time.monotonic()<end:
            self.check()
            pos=self.match(name)
            if pos:
                self.wait(.35)
                again=self.match(name)
                if again and abs(again[0]-pos[0])<15 and abs(again[1]-pos[1])<15:
                    return again
            self.wait(.8)
        raise RuntimeError(f'Timed out detecting {name}. Check Imageye, browser zoom and templates.')
    def click(self,name,timeout):
        pos=self.find(name,timeout)
        self.require_chrome()
        pg.click(*pos)
        self.log(f'Clicked {name}')
    def wait_download(self,before):
        started=time.monotonic()
        minimum=self.c['download_wait']
        end=started+self.c['download_timeout']
        self.log(f'Minimum download wait: {minimum:g} seconds before closing tab.')
        previous=None; quiet_since=started; count=0
        while time.monotonic()<end:
            self.check()
            now=changes(before,snapshot(self.c['folder']))
            pending=any(p.lower().endswith(TEMP_EXT) for p in now)
            finished={p:v for p,v in now.items() if not p.lower().endswith(TEMP_EXT) and v[0]>0}
            if now != previous:
                quiet_since=time.monotonic(); previous=now
            if len(finished)!=count:
                count=len(finished); self.log(f'New/updated nonempty files: {count}')
            if finished and not pending and time.monotonic()-started>=minimum and time.monotonic()-quiet_since>=self.c['quiet']:
                return len(finished)
            self.wait(1)
        raise RuntimeError('Download completion could not be inferred from the selected folder. Tab left open; check Chrome downloads manually.')
    def run(self):
        done=0
        try:
            chrome=chrome_path()
            for i,url in enumerate(self.c['urls'],1):
                self.check()
                self.log(f'[{i}/{len(self.c["urls"])}] {url}')
                subprocess.Popen([chrome,'--new-tab',url])
                self.wait(self.c['page_wait'])
                self.require_chrome()
                # The side panel may persist between tabs; if so, don't blindly toggle it.
                if self.match('select_all') or self.match('download'):
                    raise RuntimeError('Imageye side panel is already displaying results. Close it and restart from this URL to avoid stale selections.')
                self.click('extension',20)
                self.click('select_all',self.c['scan_timeout'])
                before=snapshot(self.c['folder'])
                self.click('download',30)
                count=self.wait_download(before)
                self.log(f'Download folder settled: {count} file(s).')
                self.require_chrome()
                # Close the side panel via its header X if configured. The user can calibrate its position.
                if self.c['close_xy']:
                    x,y=self.c['close_xy']
                    sw,sh=pg.size()
                    if not (sw*.85 <= x < sw and 0 <= y < sh*.18):
                        raise RuntimeError('Side panel close point is outside the upper-right header; tab left open.')
                    pg.click(x,y); self.wait(.5)
                self.require_chrome()
                pg.hotkey('ctrl','w')
                done+=1
                self.events.put(('progress',done))
                self.wait(1)
            self.log('Queue complete.')
        except (Stopped,pg.FailSafeException):
            self.log('Stopped. Current tab left open.')
        except Exception as e:
            self.log(f'ERROR: {e}')
        finally:
            self.events.put(('done',done))

class App:
    def __init__(self,root):
        self.root=root; self.runner=None; self.events=queue.Queue(); self.close_xy=None
        root.title('Imageye Queue Automation'); root.geometry('970x690'); root.minsize(920,600)
        f=ttk.Frame(root,padding=14); f.pack(fill='both',expand=True)
        ttk.Label(f,text='Imageye Queue Automation',font=('Segoe UI',18,'bold')).pack(anchor='w')
        ttk.Label(f,text='Windows • Chrome • Authorized image downloads only').pack(anchor='w',pady=(0,10))
        row=ttk.Frame(f); row.pack(fill='x'); ttk.Label(row,text='Links (one URL per line)').pack(side='left'); ttk.Button(row,text='Load links.txt',command=self.load).pack(side='right')
        self.urls=tk.Text(f,height=8,wrap='none'); self.urls.pack(fill='both',expand=True,pady=(4,8))
        row=ttk.Frame(f); row.pack(fill='x'); ttk.Label(row,text='Chrome download folder').pack(side='left'); self.folder=tk.StringVar(value=str(Path.home()/'Downloads')); ttk.Entry(row,textvariable=self.folder).pack(side='left',fill='x',expand=True,padx=6); ttk.Button(row,text='Browse',command=self.browse).pack(side='left')
        opts=ttk.Frame(f); opts.pack(fill='x',pady=9); self.vars={}
        for i,(key,label,default) in enumerate([('page_wait','Page wait (s)','8'),('scan_timeout','Scan timeout (s)','180'),('download_wait','Min. download wait (s)','60'),('download_timeout','Download timeout (s)','600'),('quiet','Folder quiet (s)','20'),('confidence','Match confidence','0.86')]):
            ttk.Label(opts,text=label).grid(row=0,column=i,sticky='w',padx=3); v=tk.StringVar(value=default); self.vars[key]=v; ttk.Entry(opts,textvariable=v,width=12).grid(row=1,column=i,sticky='ew',padx=3); opts.columnconfigure(i,weight=1)
        row=ttk.Frame(f); row.pack(fill='x'); ttk.Button(row,text='Calibrate panel X (optional)',command=self.calibrate).pack(side='left'); self.cal_label=ttk.Label(row,text='Not set'); self.cal_label.pack(side='left',padx=8)
        self.auth=tk.BooleanVar(); ttk.Checkbutton(f,text='I have permission to download the selected images.',variable=self.auth).pack(anchor='w',pady=7)
        row=ttk.Frame(f); row.pack(fill='x'); self.start_btn=ttk.Button(row,text='Start',command=self.start); self.start_btn.pack(side='left'); self.pause_btn=ttk.Button(row,text='Pause',command=self.toggle,state='disabled'); self.pause_btn.pack(side='left',padx=5); self.stop_btn=ttk.Button(row,text='Stop',command=self.stop,state='disabled'); self.stop_btn.pack(side='left'); self.status=ttk.Label(row,text='Ready'); self.status.pack(side='right')
        self.bar=ttk.Progressbar(f,mode='determinate'); self.bar.pack(fill='x',pady=8)
        self.logs=tk.Text(f,height=8,state='disabled',wrap='word'); self.logs.pack(fill='both',expand=True)
        ttk.Label(f,text='Emergency stop: move mouse to the top-left screen corner. Do not use Chrome while running.').pack(anchor='w',pady=(6,0))
        root.after(150,self.poll); root.protocol('WM_DELETE_WINDOW',self.close)
    def load(self):
        p=filedialog.askopenfilename(filetypes=[('Text files','*.txt'),('All files','*.*')]);
        if p:
            self.urls.delete('1.0','end'); self.urls.insert('1.0',Path(p).read_text(encoding='utf-8-sig'))
    def browse(self):
        p=filedialog.askdirectory(initialdir=self.folder.get());
        if p:self.folder.set(p)
    def calibrate(self):
        if self.runner:return
        messagebox.showinfo('Calibration','Open Chrome with Imageye side panel visible. After pressing OK, move the cursor onto the side panel X (top right) within 5 seconds. Do not click it.')
        self.root.iconify(); self.root.after(5000,self.capture)
    def capture(self):
        p=pg.position(); self.close_xy=(p.x,p.y); self.cal_label.config(text=f'Set: {p.x}, {p.y}'); self.root.deiconify()
    def start(self):
        try:
            if os.name!='nt':raise ValueError('Windows only.')
            if not self.auth.get():raise ValueError('Confirm download permission first.')
            urls=[s.strip() for s in self.urls.get('1.0','end').splitlines() if s.strip()]
            if not urls or any(urlparse(s).scheme not in ('http','https') or not urlparse(s).netloc for s in urls):raise ValueError('Enter valid HTTP(S) links, one per line.')
            folder=Path(self.folder.get()).expanduser();
            if not folder.is_dir():raise ValueError('Select the existing Chrome download folder.')
            c={k:float(v.get()) for k,v in self.vars.items()};
            if c['page_wait']<3 or c['scan_timeout']<10 or not 60<=c['download_wait']<=180 or c['download_timeout']<=c['download_wait'] or c['quiet']<10 or not .8<=c['confidence']<=.99:raise ValueError('Invalid timing or confidence. Minimum: page 3s, scan 10s, download wait 60–180s, timeout greater than wait, quiet 10s; confidence 0.80–0.99.')
            c.update(urls=urls,folder=folder,close_xy=self.close_xy)
            self.runner=Runner(c,self.events)
        except Exception as e:messagebox.showerror('Cannot start',str(e));return
        self.bar.configure(maximum=len(urls),value=0); self.status.config(text=f'0 / {len(urls)}'); self.start_btn.config(state='disabled'); self.pause_btn.config(state='normal',text='Pause'); self.stop_btn.config(state='normal'); self.root.iconify(); threading.Thread(target=self.runner.run,daemon=True).start()
    def toggle(self):
        if not self.runner:return
        if self.runner.pause.is_set():self.runner.pause.clear();self.pause_btn.config(text='Pause');self.root.iconify()
        else:self.runner.pause.set();self.pause_btn.config(text='Resume')
    def stop(self):
        if self.runner:self.runner.stop.set()
    def poll(self):
        try:
            while True:
                kind,v=self.events.get_nowait()
                if kind=='log':
                    self.logs.config(state='normal'); self.logs.insert('end',time.strftime('%H:%M:%S')+' '+v+'\n'); self.logs.see('end'); self.logs.config(state='disabled')
                elif kind=='progress':self.bar['value']=v; self.status.config(text=f'{v} / {int(float(self.bar["maximum"]))}')
                elif kind=='done':
                    self.runner=None; self.start_btn.config(state='normal'); self.pause_btn.config(state='disabled'); self.stop_btn.config(state='disabled'); self.root.deiconify(); self.status.config(text=f'{v} completed')
        except queue.Empty:pass
        self.root.after(150,self.poll)
    def close(self):
        if self.runner:self.runner.stop.set()
        self.root.destroy()

if __name__=='__main__':
    root=tk.Tk(); App(root); root.mainloop()
