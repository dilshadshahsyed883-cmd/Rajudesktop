"""Voice to SRT Studio - standalone local Windows subtitle generator."""

from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from srt_engine import DURATION_MODES, save_srt, transcribe_file, words_to_cues, seconds_to_srt

APP_NAME = "Voice to SRT Studio"
AUDIO_TYPES = [
    ("Audio / Video files", "*.mp3 *.wav *.m4a *.flac *.ogg *.wma *.mp4 *.mkv *.aac *.webm"),
    ("All files", "*.*"),
]
BG = "#101726"
PANEL = "#1b2639"
ENTRY = "#26374e"
FG = "#eef3fb"
MUTED = "#a3b0c4"
ACCENT = "#307bd6"


def settings_file() -> Path:
    root = Path(os.environ.get("APPDATA") or Path.home()) / "VoiceToSRTStudio"
    root.mkdir(parents=True, exist_ok=True)
    return root / "settings.json"


def load_settings() -> dict:
    try:
        return json.loads(settings_file().read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("900x715")
        self.minsize(700, 610)
        self.configure(bg=BG)
        self.settings = load_settings()
        self.messages: queue.Queue = queue.Queue()
        self.cancel_event = threading.Event()
        self.is_working = False
        self.last_output: Path | None = None
        self.source_var = tk.StringVar()
        self.folder_var = tk.StringVar(value=self.settings.get("folder", ""))
        self.model_var = tk.StringVar(value=self.settings.get("model", "small"))
        if self.model_var.get() not in {"tiny", "base", "small", "medium"}:
            self.model_var.set("small")
        self.language_var = tk.StringVar(value=self.settings.get("language", "Auto detect"))
        self.duration_var = tk.StringVar(value=self.settings.get("duration", "Balanced (3-4 sec)"))
        if self.duration_var.get() not in DURATION_MODES:
            self.duration_var.set("Balanced (3-4 sec)")
        self.status_var = tk.StringVar(value="Ready - choose your voice file")
        self._style()
        self._create_ui()
        self.after(100, self._consume_messages)
        self.protocol("WM_DELETE_WINDOW", self._exit)

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("Main.TFrame", background=BG)
        style.configure("Panel.TFrame", background=PANEL)
        style.configure("Title.TLabel", background=BG, foreground=FG, font=("Segoe UI", 23, "bold"))
        style.configure("Sub.TLabel", background=BG, foreground=MUTED, font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background=PANEL, foreground=FG, font=("Segoe UI", 10))
        style.configure("Hint.TLabel", background=PANEL, foreground=MUTED, font=("Segoe UI", 9))
        style.configure("Main.TButton", padding=(15, 9), font=("Segoe UI", 10, "bold"))
        style.configure("TCombobox", fieldbackground=ENTRY, background=ENTRY, foreground="#121c2d", padding=7)
        style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor=ENTRY)

    def _create_ui(self):
        container = ttk.Frame(self, style="Main.TFrame", padding=22)
        container.pack(fill="both", expand=True)
        ttk.Label(container, text="VOICE → SRT STUDIO", style="Title.TLabel").pack(anchor="w")
        ttk.Label(container, text="Audio se accurately timestamped subtitles • English, Urdu, Hindi aur doosri languages", style="Sub.TLabel").pack(anchor="w", pady=(3, 15))

        p = ttk.Frame(container, style="Panel.TFrame", padding=17)
        p.pack(fill="x")
        ttk.Label(p, text="1. Choose voice file", style="Panel.TLabel").pack(anchor="w", pady=(0, 7))
        source_row = ttk.Frame(p, style="Panel.TFrame")
        source_row.pack(fill="x")
        tk.Entry(source_row, textvariable=self.source_var, font=("Segoe UI", 10), bg=ENTRY, fg=FG,
                 insertbackground=FG, relief="flat", bd=9).pack(side="left", expand=True, fill="x")
        ttk.Button(source_row, text="Browse audio", command=self._pick_source).pack(side="left", padx=(10, 0))
        ttk.Label(p, text="Supports MP3, WAV, M4A, FLAC, AAC, MP4, MKV etc.", style="Hint.TLabel").pack(anchor="w", pady=(6, 15))

        ttk.Label(p, text="2. Save .srt file to (blank = same folder as voice)", style="Panel.TLabel").pack(anchor="w", pady=(0, 7))
        output_row = ttk.Frame(p, style="Panel.TFrame")
        output_row.pack(fill="x")
        tk.Entry(output_row, textvariable=self.folder_var, font=("Segoe UI", 10), bg=ENTRY, fg=FG,
                 insertbackground=FG, relief="flat", bd=9).pack(side="left", expand=True, fill="x")
        ttk.Button(output_row, text="Choose folder", command=self._pick_output).pack(side="left", padx=(10, 0))
        ttk.Button(output_row, text="Same as voice", command=lambda: self.folder_var.set("")).pack(side="left", padx=(5, 0))

        settings_row = ttk.Frame(p, style="Panel.TFrame")
        settings_row.pack(fill="x", pady=(15, 0))
        for i in range(3):
            settings_row.columnconfigure(i, weight=1, uniform="s")
        self._option(settings_row, 0, "Speech model", self.model_var, ("tiny", "base", "small", "medium"))
        self._option(settings_row, 1, "Language", self.language_var,
                     ("Auto detect", "English", "Urdu", "Hindi", "Arabic", "Spanish", "French"))
        self._option(settings_row, 2, "Subtitle length", self.duration_var, tuple(DURATION_MODES))
        ttk.Label(p, text="Small = better accuracy; Base/Tiny = faster. Speech timestamps follow voice, not fixed intervals.", style="Hint.TLabel").pack(anchor="w", pady=(10, 0))

        actions = ttk.Frame(container, style="Main.TFrame")
        actions.pack(fill="x", pady=(16, 8))
        self.start_btn = ttk.Button(actions, text="Generate SRT", command=self._start, style="Main.TButton")
        self.start_btn.pack(side="left")
        self.cancel_btn = ttk.Button(actions, text="Cancel", command=self.cancel_event.set, state="disabled")
        self.cancel_btn.pack(side="left", padx=8)
        self.open_btn = ttk.Button(actions, text="Open output folder", command=self._open_output, state="disabled")
        self.open_btn.pack(side="right")
        ttk.Label(container, textvariable=self.status_var, style="Sub.TLabel").pack(anchor="w", pady=(6, 6))
        self.progress = ttk.Progressbar(container, mode="indeterminate", maximum=100)
        self.progress.pack(fill="x", pady=(0, 11))
        ttk.Label(container, text="SRT preview", style="Sub.TLabel").pack(anchor="w", pady=(0, 5))
        wrap = ttk.Frame(container, style="Main.TFrame")
        wrap.pack(fill="both", expand=True)
        self.preview = tk.Text(wrap, bg=PANEL, fg=FG, insertbackground=FG, relief="flat",
                               font=("Consolas", 10), wrap="word", padx=15, pady=10, state="disabled")
        sb = ttk.Scrollbar(wrap, command=self.preview.yview)
        self.preview.configure(yscrollcommand=sb.set)
        self.preview.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self._write_preview("Select your voice and click Generate SRT.\n\nThe model downloads one time on first run. Afterwards it works offline.")

    def _option(self, parent, col, heading, variable, options):
        holder = ttk.Frame(parent, style="Panel.TFrame")
        holder.grid(row=0, column=col, sticky="ew", padx=(0 if col == 0 else 7, 0))
        ttk.Label(holder, text=heading, style="Panel.TLabel").pack(anchor="w", pady=(0, 5))
        cb = ttk.Combobox(holder, state="readonly", textvariable=variable, values=options)
        cb.pack(fill="x")

    def _write_preview(self, text):
        self.preview.config(state="normal")
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", text)
        self.preview.config(state="disabled")

    def _pick_source(self):
        selected = filedialog.askopenfilename(title="Choose audio file", filetypes=AUDIO_TYPES)
        if selected:
            self.source_var.set(selected)
            self.last_output = None
            self.open_btn.config(state="disabled")

    def _pick_output(self):
        selected = filedialog.askdirectory(title="Choose output folder")
        if selected:
            self.folder_var.set(selected)

    def _save_settings(self):
        data = {"folder": self.folder_var.get(), "model": self.model_var.get(),
                "language": self.language_var.get(), "duration": self.duration_var.get()}
        try:
            settings_file().write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError:
            pass

    def _start(self):
        if self.is_working:
            return
        source = Path(self.source_var.get().strip().strip('"')).expanduser()
        if not source.is_file():
            messagebox.showerror("Missing audio", "Please select an existing audio file.")
            return
        output_dir = self.folder_var.get().strip().strip('"')
        output = (Path(output_dir).expanduser() if output_dir else source.parent) / (source.stem + ".srt")
        language_map = {"Auto detect": None, "English": "en", "Urdu": "ur", "Hindi": "hi",
                        "Arabic": "ar", "Spanish": "es", "French": "fr"}
        language = language_map.get(self.language_var.get())
        model = self.model_var.get()
        mode = self.duration_var.get()
        if output.exists() and not messagebox.askyesno("Replace SRT?", f"File already exists:\n{output}\n\nReplace it?"):
            return
        self._save_settings()
        self.cancel_event.clear()
        self.is_working = True
        self.last_output = None
        self.start_btn.config(state="disabled")
        self.cancel_btn.config(state="normal")
        self.open_btn.config(state="disabled")
        self.status_var.set("Starting transcription...")
        self.progress.config(mode="indeterminate")
        self.progress.start(12)
        self._write_preview("Reading and transcribing audio...\n\nProgress will appear here after recognition.")
        threading.Thread(target=self._worker, args=(source, output, model, language, mode), daemon=True).start()

    def _worker(self, source, output, model, language, mode):
        try:
            words, detected_language = transcribe_file(
                source, model, language,
                progress=lambda msg, pct: self.messages.put(("progress", msg, pct)),
                cancelled=self.cancel_event.is_set,
            )
            if self.cancel_event.is_set():
                raise InterruptedError("Transcription cancelled")
            cues = words_to_cues(words, mode)
            if not cues:
                raise ValueError("No subtitle words detected")
            if self.cancel_event.is_set():
                raise InterruptedError("Transcription cancelled")
            save_srt(output, cues)
            preview = "\n\n".join(
                f"{i}\n{seconds_to_srt(c.start)} --> {seconds_to_srt(c.end)}\n{c.text}"
                for i, c in enumerate(cues[:150], 1)
            )
            if len(cues) > 150:
                preview += f"\n\n... and {len(cues)-150} more subtitles (see the SRT file)."
            self.messages.put(("done", output, len(cues), detected_language, preview))
        except InterruptedError as ex:
            self.messages.put(("cancelled", str(ex)))
        except Exception as ex:
            self.messages.put(("error", f"{type(ex).__name__}: {ex}"))

    def _consume_messages(self):
        try:
            while True:
                item = self.messages.get_nowait()
                kind = item[0]
                if kind == "progress":
                    _, msg, pct = item
                    self.status_var.set(msg)
                    if pct is not None:
                        if str(self.progress.cget("mode")) != "determinate":
                            self.progress.stop()
                            self.progress.config(mode="determinate")
                        self.progress["value"] = pct
                elif kind == "done":
                    _, output, count, lang, preview = item
                    self.last_output = output
                    self._finish()
                    self.open_btn.config(state="normal")
                    self.status_var.set(f"DONE — {count} subtitles | language: {lang} | saved: {output.name}")
                    self._write_preview(preview)
                    messagebox.showinfo("SRT ready", f"Created {count} synchronized subtitles.\n\nSaved to:\n{output}")
                elif kind == "cancelled":
                    self._finish()
                    self.status_var.set("Cancelled. No new SRT saved.")
                elif kind == "error":
                    self._finish()
                    self.status_var.set("Could not generate SRT")
                    self._write_preview(item[1])
                    messagebox.showerror("SRT error", item[1] + "\n\nCheck that audio contains speech and internet is available for first model download.")
        except queue.Empty:
            pass
        self.after(100, self._consume_messages)

    def _finish(self):
        self.is_working = False
        self.progress.stop()
        self.progress.config(mode="determinate")
        self.progress["value"] = 100 if self.last_output else 0
        self.start_btn.config(state="normal")
        self.cancel_btn.config(state="disabled")

    def _open_output(self):
        if self.last_output:
            folder = str(self.last_output.parent)
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])

    def _exit(self):
        if self.is_working and not messagebox.askyesno("Transcription in progress", "Close the app? Current transcription will stop without saving."):
            return
        self.cancel_event.set()
        self._save_settings()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
