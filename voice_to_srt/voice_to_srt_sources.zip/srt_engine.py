"""Word-aligned SRT subtitles for local speech recordings.

Whisper supplies *measured* word start/end times. We never derive times from
character counts or assume that someone speaks a fixed number of words/second.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable


@dataclass(frozen=True)
class Word:
    start: float
    end: float
    text: str


@dataclass(frozen=True)
class Cue:
    start: float
    end: float
    text: str


DURATION_MODES = {
    "Short (2-3 sec)": (2.5, 3.0),
    "Balanced (3-4 sec)": (3.5, 4.0),
    "Long (4-5 sec)": (4.5, 5.0),
}


def normalize_words(words: Iterable[Word]) -> list[Word]:
    """Clean timing anomalies without re-timing speech based on assumptions."""
    clean: list[Word] = []
    for w in words:
        txt = re.sub(r"\s+", " ", w.text).strip()
        if not txt or not (math.isfinite(w.start) and math.isfinite(w.end)):
            continue
        start = max(0.0, float(w.start))
        end = max(start + 0.001, float(w.end))
        clean.append(Word(start, end, txt))
    clean.sort(key=lambda w: (w.start, w.end))
    return clean


def _joined(words: list[Word]) -> str:
    """Keep language-friendly spacing and attach punctuation."""
    text = ""
    for w in words:
        token = w.text.strip()
        if not token:
            continue
        if not text:
            text = token
        elif token[0] in ",.!?;:%)]}،۔؟" or token.startswith(("'", "’")):
            text += token
        elif text.endswith(("(", "[", "{", "“", '"')):
            text += token
        elif re.match(r"^[\u4e00-\u9fff\u3040-\u30ff]", token) and re.search(r"[\u4e00-\u9fff\u3040-\u30ff]$", text):
            text += token
        else:
            text += " " + token
    return text


def _block_cues(block: list[Word], target: float, max_dur: float) -> list[Cue]:
    """Dynamic-programming line breaks: natural punctuation + ~target duration."""
    n = len(block)
    dp = [float("inf")] * (n + 1)
    nxt = [n] * (n + 1)
    dp[n] = 0.0

    for i in range(n - 1, -1, -1):
        for j in range(i + 1, min(i + 25, n + 1)):
            dur = block[j - 1].end - block[i].start
            line = _joined(block[i:j])
            if dur > max_dur + 1.7 and j > i + 1:
                break
            # Crossing a sentence boundary in a caption is disfavoured.
            crossed = sum(bool(re.search(r"[.!?。？！؟۔]$", w.text.strip())) for w in block[i:j - 1])
            penalty = 0.30 * (dur - target) ** 2 + 1.5 * max(0, dur - max_dur) ** 2
            penalty += 1.25 * max(0, 1.6 - dur) ** 2
            penalty += 0.6 * max(0, len(line) - 86) ** 2
            penalty += 2.2 * crossed
            # Prefer break after punctuation or a comma when choices are close.
            if re.search(r"[.!?。？！؟۔]$", block[j - 1].text.strip()):
                penalty -= 0.25
            elif re.search(r"[,;:،]$", block[j - 1].text.strip()):
                penalty -= 0.10
            if j < n and block[j].start - block[j - 1].end > 0.35:
                penalty -= 0.2
            score = 1.25 + max(0.0, penalty) + dp[j]
            if score < dp[i]:
                dp[i] = score
                nxt[i] = j

    cues: list[Cue] = []
    i = 0
    while i < n:
        j = nxt[i]
        if j <= i:
            j = i + 1
        line_words = block[i:j]
        cues.append(Cue(line_words[0].start, line_words[-1].end, _joined(line_words)))
        i = j
    return cues


def words_to_cues(words: Iterable[Word], mode: str = "Balanced (3-4 sec)") -> list[Cue]:
    if mode not in DURATION_MODES:
        raise ValueError(f"Unknown subtitle duration mode: {mode}")
    target, max_dur = DURATION_MODES[mode]
    clean = normalize_words(words)
    if not clean:
        return []

    # Spoken phrases separated by silence receive their own subtitles.
    blocks: list[list[Word]] = []
    block: list[Word] = []
    for w in clean:
        if block and w.start - block[-1].end >= 0.90:
            blocks.append(block)
            block = []
        block.append(w)
    if block:
        blocks.append(block)

    raw = [cue for b in blocks for cue in _block_cues(b, target, max_dur)]
    aligned: list[Cue] = []
    for cue in raw:
        start = cue.start
        if aligned:
            # Word timestamp models occasionally produce slight overlaps.
            start = max(start, aligned[-1].end)
        end = max(start + 0.001, cue.end)
        aligned.append(Cue(start, end, cue.text))
    return aligned


def seconds_to_srt(value: float) -> str:
    millis = max(0, round(value * 1000))
    hours, rem = divmod(millis, 3_600_000)
    mins, rem = divmod(rem, 60_000)
    secs, ms = divmod(rem, 1_000)
    return f"{hours:02d}:{mins:02d}:{secs:02d},{ms:03d}"


def render_srt(cues: Iterable[Cue]) -> str:
    return "\n\n".join(
        f"{i}\n{seconds_to_srt(c.start)} --> {seconds_to_srt(c.end)}\n{c.text}"
        for i, c in enumerate(cues, 1)
    ) + "\n"


def transcribe_file(
    source: Path,
    model_name: str = "small",
    language: str | None = None,
    progress: Callable[[str, float | None], None] | None = None,
    cancelled: Callable[[], bool] | None = None,
) -> tuple[list[Word], str]:
    """Decode locally with Faster-Whisper; model files download once on first use."""
    if not source.is_file():
        raise FileNotFoundError(f"Audio not found: {source}")
    if model_name not in {"tiny", "base", "small", "medium"}:
        raise ValueError("Invalid transcription model")
    if progress:
        progress(f"Loading {model_name} transcription model (first run may download it)...", None)
    from faster_whisper import WhisperModel  # lazy import for fast GUI startup

    # CPU int8 runs on typical Windows laptops without an NVIDIA GPU.
    model = WhisperModel(model_name, device="cpu", compute_type="int8", cpu_threads=0)
    if cancelled and cancelled():
        raise InterruptedError("Transcription cancelled")
    if progress:
        progress("Recognizing speech and calculating word timestamps...", 0)
    segments, info = model.transcribe(
        str(source),
        language=language,
        beam_size=5,
        word_timestamps=True,
        vad_filter=True,
        condition_on_previous_text=False,
    )
    all_words: list[Word] = []
    for seg in segments:
        if cancelled and cancelled():
            raise InterruptedError("Transcription cancelled")
        if seg.words:
            for w in seg.words:
                all_words.append(Word(float(w.start), float(w.end), w.word))
        elif seg.text.strip():
            # Rare model fallback: segment-level timestamps remain audio-aligned.
            all_words.append(Word(float(seg.start), float(seg.end), seg.text))
        if progress:
            p = min(99.0, max(0.0, float(seg.end) / max(float(info.duration), .001) * 100))
            progress(f"Transcribing... {p:.0f}%", p)
    if not all_words:
        raise ValueError("No speech detected. Check that the file contains audible voice.")
    return all_words, (info.language or "unknown")


def save_srt(dest: Path, cues: list[Cue]) -> None:
    if not cues:
        raise ValueError("No subtitle captions to save")
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Atomic replacement: never leave half-written subtitles on an error.
    import os
    import tempfile

    temporary: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w", encoding="utf-8-sig", newline="\n", dir=dest.parent,
            prefix=f".{dest.stem}_", suffix=".tmp", delete=False,
        ) as f:
            temporary = f.name
            f.write(render_srt(cues))
        os.replace(temporary, dest)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
